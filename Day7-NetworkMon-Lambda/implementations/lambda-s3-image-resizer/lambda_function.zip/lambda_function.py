import json
import boto3
import io, os
from PIL import Image


s3_client = boto3.client('s3')

def lambda_handler(event, context):
    """
    Lambda handler function to resize images uploaded to an S3 bucket.
    The resized image is saved to another S3 bucket.
    """
    
    # Log the incoming event for debugging purposes
    print("Received event: " + json.dumps(event, indent=2))

    # Extract bucket and object key from the event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    # Download the image from the S3 bucket
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        image_data = response['Body'].read()

        # Open the image with PIL
        image = Image.open(io.BytesIO(image_data))

        # Resize the image
        resized_image = image.resize((256, 256))  

        # Save the resized image to a buffer
        buffer = io.BytesIO()
        resized_image.save(buffer, format=image.format)
        buffer.seek(0)

        # Specify the output bucket and key
        output_bucket = os.environ["OUTPUT_BUCKET"]
        output_key = key.replace('input/', 'output/')

        # Upload the resized image to the output bucket
        s3_client.put_object(Bucket=output_bucket, Key=output_key, Body=buffer.getvalue())
        print(f"Resized image saved to {output_bucket}/{output_key}")

    except Exception as e:
        print(f"Error processing file {key} from bucket {bucket}: {str(e)}")
        raise

    return {
        'statusCode': 200,
        'body': json.dumps('Image resized successfully!')
    }
